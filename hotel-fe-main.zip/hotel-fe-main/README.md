# Hotel

# Add API_ENDPOINT

- Go to packages/hotel/.env and provide REACT_APP_API_ENDPOINT. It should be the java server endpoint

### To Run the project in dev env:

- yarn & yarn start
