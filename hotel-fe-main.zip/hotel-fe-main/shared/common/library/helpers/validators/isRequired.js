export const isRequired = value => (!value ? 'Required!' : '');
