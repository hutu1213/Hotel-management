import { Checkbox } from 'antd';
// import AntCheckbox from './Checkbox.style';

// const checkbox = AntCheckbox(Checkbox);
// const CheckboxGroup = Checkbox.Group;

export default Checkbox;
// export { CheckboxGroup };
