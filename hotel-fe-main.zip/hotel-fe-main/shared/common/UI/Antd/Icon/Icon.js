import { Icon } from 'antd';
export default Icon;
