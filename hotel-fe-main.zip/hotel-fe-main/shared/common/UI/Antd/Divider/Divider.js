import { Divider } from 'antd';
export default Divider;
