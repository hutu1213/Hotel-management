import { Alert } from 'antd';

export default Alert;
