import { Tabs } from 'antd';
// import AntTab from './Tab.style';
// import WithDirection from '../../../hocs/withDirection';

// const WDTabs = AntTab(Tabs);
// const TabPane = Tabs.TabPane;
// const isoTabs = WithDirection(WDTabs);

export default Tabs;
// export { TabPane };
