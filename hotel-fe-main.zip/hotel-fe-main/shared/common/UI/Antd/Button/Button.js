import { Button } from 'antd';

export default Button;
