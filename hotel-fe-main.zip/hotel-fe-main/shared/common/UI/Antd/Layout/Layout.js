import { Layout } from 'antd';
export default Layout;
