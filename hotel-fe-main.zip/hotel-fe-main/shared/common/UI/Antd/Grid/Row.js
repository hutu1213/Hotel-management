import { Row } from 'antd';

export default Row;
