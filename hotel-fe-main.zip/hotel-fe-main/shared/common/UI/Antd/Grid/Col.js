import { Col } from 'antd';
export default Col;
