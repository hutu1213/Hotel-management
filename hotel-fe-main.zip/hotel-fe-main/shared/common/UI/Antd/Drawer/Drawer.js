import { Drawer } from 'antd';

export default Drawer;
