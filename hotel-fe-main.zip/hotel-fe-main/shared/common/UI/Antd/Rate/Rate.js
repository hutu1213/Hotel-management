import { Rate } from 'antd';
// import Ratings from './Rating.style';
// import WithDirection from '../../../hocs/withDirection';

// const AntRating = Ratings(Rate);
// const Rating = WithDirection(AntRating);
export default Rate;
