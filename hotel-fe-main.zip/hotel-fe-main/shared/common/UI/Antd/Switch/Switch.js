import styled from 'styled-components';
// import { palette } from 'styled-theme';
import { Switch } from 'antd';

// const AntSwitch = styled(Switch)`
//   /* &.ant-switch-checked {
//     /* border-color: ${palette('primary', 0)}; */
//     /* background-color: ${palette('primary', 0)}; *
//    */
// `;

export default Switch;
