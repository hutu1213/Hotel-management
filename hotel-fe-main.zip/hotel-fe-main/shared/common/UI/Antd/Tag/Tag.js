import { Tag } from 'antd';

export default Tag;
