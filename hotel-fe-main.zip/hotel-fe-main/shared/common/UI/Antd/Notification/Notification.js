import { notification } from 'antd';
import 'antd/lib/notification/style/index.css';

export default notification;
