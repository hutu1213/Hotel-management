package nhom8.javabackend.hotel.user.dto.userimage;

import lombok.Data;

@Data
public class UpdateUserImageDto {
	private Long id;
	
	private String name;
	
	private String url;
}
