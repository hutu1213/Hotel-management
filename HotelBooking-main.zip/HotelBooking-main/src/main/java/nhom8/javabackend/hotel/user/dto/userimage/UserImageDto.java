package nhom8.javabackend.hotel.user.dto.userimage;

public interface UserImageDto {
	
	public Long getId();
	
	public String getName();
	
	public String getUrl();
}
