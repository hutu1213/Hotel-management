package nhom8.javabackend.hotel.hotel.dto.hotelimages;


public interface HotelImagesDto {
	public Long getId();
	
	public String getUrl();
	
	public String getThumbUrl();
	
	public Long getHotelId();
}
