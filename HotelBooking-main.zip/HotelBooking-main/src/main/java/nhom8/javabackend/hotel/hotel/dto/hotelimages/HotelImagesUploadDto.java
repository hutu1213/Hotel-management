package nhom8.javabackend.hotel.hotel.dto.hotelimages;

import lombok.Data;

@Data
public class HotelImagesUploadDto {
	
	private String url;
	
	private String thumbUrl;
	
	private String name;
}
