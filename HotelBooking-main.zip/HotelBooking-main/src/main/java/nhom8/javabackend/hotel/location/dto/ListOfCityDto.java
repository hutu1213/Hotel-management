package nhom8.javabackend.hotel.location.dto;

public interface ListOfCityDto {
	public String getCity();
	public Long getNumberOfHotel();
}
