package nhom8.javabackend.hotel.hotel.util;

public enum Status {
	PUBLISH,
	DRAFT
}
