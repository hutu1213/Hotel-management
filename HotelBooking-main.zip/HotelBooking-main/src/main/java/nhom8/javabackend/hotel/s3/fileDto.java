package nhom8.javabackend.hotel.s3;

import lombok.Data;

@Data
public class fileDto {
	private String fileName;
}
