package nhom8.javabackend.hotel.user.util;

public enum Role {
	ADMIN,
	USER
}
